print('Enter the side of square to determine the area of sqaure :')
side=int(input('Side :'))
areaofsqaure=side*side
print('Area of the sqaure are :',areaofsqaure)