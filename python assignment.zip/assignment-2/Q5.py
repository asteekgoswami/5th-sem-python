num=input('Enter the number :')
print('The occurance of digit five in a ',num,' is :',num.count('5'))