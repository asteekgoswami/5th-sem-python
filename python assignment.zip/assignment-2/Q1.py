from cmath import *
import cmath

# radius=int(input('Enter the radius of the circle :'))
# area=pi*radius**2
# print('Area of the circle with radius ',radius,' are :',round(area,2))

# print("Enter the value of base and height to find the area of triangle :")
# base=int(input('Base :'))
# height=int(input('Height :'))
# areaoftriangle=base*height/2
# print('Area of triangle are :','%.2f'%areaoftriangle)

# print('Enter the value of length and width to find the area of rectangle ')
# len=int(input('Length :'))
# wid=int(input('Width :'))
# areaofrectangle=len*wid
# print('Area of rectangle are :{0:.2f}'.format(areaofrectangle))

# print('Enter the side of square to determine the area of sqaure :')
# side=float(input('Side :'))
# areaofsqaure=side*side
# print('Area of the sqaure are :','%.2f'%areaofsqaure)


# print('Enter the value to determine the area of trapezoid :')
# base1=float(input('Base 1 :'))
# base2=float(input('Base 2 :'))
# height=float(input('Height :'))

# areaoftrapezoid=(base1+base2 )/2* height

# print('Area of trapezoid :','%.2f'%areaoftrapezoid)

# rad=float(input('Enter the radius of sphere to find the area of sphere :'))
# areaofsphere=4*pi*rad*rad
# print('Area of sphere are :','%.2f'%areaofsphere)

print("Enter the value of base and height to find the area of parallelogram :")
base=float(input('Base :'))
height=float(input('Height :'))
areaofparallelogram=base*height
print("Area of parallelogram are ",'%.2f'%areaofparallelogram)