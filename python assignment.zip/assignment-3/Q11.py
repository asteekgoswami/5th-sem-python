# lis=[1,2]
# print(hash(lis))

x=123
print(hash(x))