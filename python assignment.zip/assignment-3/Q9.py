#  Write a program to print a multiplication table.

n=int(input("Enter the number to print the multiplication table : "))
for i in range(1,11):
    print(n," * ",i," = ",n*i,)