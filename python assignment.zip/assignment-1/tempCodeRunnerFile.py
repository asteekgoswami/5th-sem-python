num=int(input('Enter the no. :'))

if num%2==0: