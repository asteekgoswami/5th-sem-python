num=int(input('Enter the no. :'))

if num%2==0:
    print(num,' is a even number')
else:
    print(num,' is a odd number')