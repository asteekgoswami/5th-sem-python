n=int(input('Enter the number that table you want :'))

for i in range(1,10+1):
    print(n," * ",i," = ",n*i)