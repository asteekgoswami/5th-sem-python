print("Enter the three no. :")
x=int(input("Enter the 1st no."))
y=int(input("Enter the 2nd no."))
z=int(input("Enter the 3rd no."))
if x>y and x>z:
    print(x," is the greatest no. ")
elif y>x and y>z:
    print(y," is the greatest no.")
else:
    print(z," is the greatest no. ")
    