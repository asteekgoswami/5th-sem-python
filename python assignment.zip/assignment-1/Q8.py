n=int(input('Enter the range to find the sum of n natural no. :'))

x=n*(n+1)//2
print('The sum of ',n,' natural no.  are :',x)
